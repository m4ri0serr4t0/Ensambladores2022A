from tkinter import messagebox
from tkinter.filedialog import askopenfile


class Archivo:

    pass