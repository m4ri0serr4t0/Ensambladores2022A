class Registro:
    def registros(self):
        registers = ['AX', 'AH', 'AL'
                     'BX', 'BH', 'BL'
                     'CX', 'CH', 'CL'
                     'DX', 'DH', 'CL'
                     'CS', 'DS', 'SS', 'ES'
                     'BP', 'SP', 'SI', 'DI'
                     ]


        return registers
